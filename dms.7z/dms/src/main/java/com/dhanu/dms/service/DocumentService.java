package com.dhanu.dms.service;

import org.dom4j.DocumentException;

import com.dhanu.dms.modal.Document;

public interface DocumentService {

	Document save(Document document);

	Document saves(Document document) throws DocumentException;

}
