package com.dhanu.dms.errorHandling;

public class DocumentException extends Exception{
	
	public DocumentException(String messege) {
		super(messege);
	}
	
	
	
}
