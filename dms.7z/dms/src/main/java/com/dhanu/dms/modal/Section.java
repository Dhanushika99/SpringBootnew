package com.dhanu.dms.modal;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Section {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private String name;
	
	@ManyToOne
	@JoinColumn(name="pageId", referencedColumnName = "id")
	@JsonIgnore
	private Page page;

	@OneToMany(mappedBy = "section",cascade = CascadeType.ALL)
    private List<Paragraph> paragraph;
	
	
	public List<Paragraph> getParagraph() {
		return paragraph;
	}

	public void setParagraph(List<Paragraph> paragraph) {
		this.paragraph = paragraph;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
	
	
	
}
