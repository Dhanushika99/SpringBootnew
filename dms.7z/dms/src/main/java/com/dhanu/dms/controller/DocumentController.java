package com.dhanu.dms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dhanu.dms.errorHandling.DocumentException;
import com.dhanu.dms.modal.Card;
import com.dhanu.dms.modal.Document;
import com.dhanu.dms.modal.Page;
import com.dhanu.dms.modal.Paragraph;
import com.dhanu.dms.modal.Section;
import com.dhanu.dms.service.DocumentService;

@RestController
@RequestMapping(value = "/dms")
public class DocumentController {

	@Autowired
	DocumentService documentservice;

	@RequestMapping(value = "/document", method = RequestMethod.POST)
	public Document save(@RequestBody Document document) {
	
		return documentservice.save(document);
	}

	@RequestMapping(value = "/document2", method = RequestMethod.POST)
	public ResponseEntity<Document> fetch(@RequestBody Document document) {
		try {
			Document doc=documentservice.saves(document);
			return ResponseEntity.ok(doc);
		}
		catch(Exception de){
			return ResponseEntity.badRequest().build();
		}
		
	}
	
	}

