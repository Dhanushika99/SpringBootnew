package com.dhanu;

import java.util.List;
import java.util.Stack;

public class Traverse {
	private Node root;
	private Tree tree;
	Traverse(Tree tree){
		this.root=tree.getRoot();
		this.tree=tree;
		traverse(root);
	}
	Stack elements= new Stack();
	public void traverse(Node root) {
		
		if(root.hasChild) {
			for(int i=0;i<root.getChildren().size();i++)
				traverse((Node)root.getChildren().get(i));
		}
		else {
			for(int i=0;i<root.getChildren().size();i++) {
				System.out.println(root.getData());
			}
			
		}
	}
	
	
}
