package com.dhanu;

import java.util.LinkedList;

public class Tree {
	private Node root;
	private LinkedList<Node> tree;
	public Node getRoot() {
		return root;
	}
	public void setRoot(Node root) {
		this.root = root;
	}
	public LinkedList<Node> getTree() {
		return tree;
	}
	public void setTree(LinkedList<Node> tree) {
		this.tree = tree;
	}
	
	
	
}
