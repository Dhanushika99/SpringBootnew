package com.dhanu;

import java.util.LinkedList;
import java.util.List;

public class Node<T> {
	private T data = null;
	private Node<T> root;
	public boolean hasright;
	public boolean hasLeft;
	public T Parent;
	public boolean hasChild;
	public int childNumber;
	private List<Node> children = new LinkedList<Node>();

	public Node(T data) {
		this.data = data;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public List<Node> getChildren() {
		return children;
	}

	public void setChildren(List<Node> children) {
		this.children = children;
	}

	public Node<T> getRoot() {
		return root;
	}

	public void setRoot(Node root) {
		this.root = root;
	}

	
}
