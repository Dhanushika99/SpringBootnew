package com.dhanu.java.exception;

public class Printer{

	void print(int noc) {
		
		if(noc<0) {
			throw new IllegalArgumentException("enter a number >0");
		}
			for (int i = noc; i != 0; i--) {
				System.out.println("printing");
			}		
	}
	
	
}
