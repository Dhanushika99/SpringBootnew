package com.dhanu.java.exception;

public class Application {

	public static void main(String[] args) {
		Printer printer=new Printer();
		printer.print(-5);

	}

}
