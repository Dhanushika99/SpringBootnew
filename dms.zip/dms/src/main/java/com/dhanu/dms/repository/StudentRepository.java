package com.dhanu.dms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dhanu.dms.modal.Document;

public interface StudentRepository extends JpaRepository<Document, Integer>{
	
}
