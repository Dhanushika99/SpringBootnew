package com.dhanu.dms.service;

import java.nio.file.FileAlreadyExistsException;
import java.util.Optional;

import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhanu.dms.modal.Card;
import com.dhanu.dms.modal.Document;
import com.dhanu.dms.modal.Page;
import com.dhanu.dms.modal.Paragraph;
import com.dhanu.dms.modal.Section;
import com.dhanu.dms.repository.StudentRepository;

@Service
public class DocumentServiceImpl implements DocumentService{

	@Autowired
	StudentRepository studentrepository;
	@Override
	public Document save(Document document) {
		
		for (Card card : document.getCard()) {
			card.setDocument(document);
			for (Page page : card.getPages()) {
				page.setCard(card);
				for (Section section : page.getSection()) {
					section.setPage(page);
					for (Paragraph paragraph : section.getParagraph()) {
						paragraph.setSection(section);
					}
				}
			}
		}
		return studentrepository.save(document);
	}
	@Override
	public Document saves(Document document) throws DocumentException{
		if(studentrepository.findById(document.getId()) != null){
			throw new DocumentException("Document id already exists");
		}
		else {
			
			return studentrepository.save(document);
		}
		
	}

}
