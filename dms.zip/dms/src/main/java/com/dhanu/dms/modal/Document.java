package com.dhanu.dms.modal;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Document {

	@Id
	private Integer id;
	private String name;
	@OneToMany(mappedBy ="document",cascade = CascadeType.ALL)
	private  List<Card> card;
	@ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name="document_publisher",
            joinColumns = @JoinColumn(name="docid",referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name="pubid",referencedColumnName = "id")
    )
	List<Publisher> publisher;
	
	public List<Publisher> getPublisher() {
		return publisher;
	}
	public void setPublisher(List<Publisher> publisher) {
		this.publisher = publisher;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Card> getCard() {
		return card;
	}
	public void setCard(List<Card> card) {
		this.card = card;
	}
	
}
